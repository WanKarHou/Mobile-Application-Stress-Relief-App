package com.example.mad_assignment;


//Import useful resources
import androidx.appcompat.app.AppCompatActivity;

// Import Intent and Bundle
import android.content.Intent;
import android.os.Bundle;

//Import some component of view
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

//This  Part is for import resources of file
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class User_Chat extends AppCompatActivity {

    //Initialize every component
    TextView tv ; // TextView tv - To view the chat conversation between user and psychologist
    EditText editTextUser;// EditText edit - Allow type in message
    Button send;//Button send - Press this button to send message
    TextView nameLabel;// namelabel - Display the name of user


    FileOutputStream fos ; //Create file
    String strFileContents = "";// Variable to store the content of message
    String filename = "";
    String text="" ;
    String psychologist_name="Psychologist ";  // Initialize the name of psychologist
    String username ="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user__chat);

        //Using getIntent() to get the file name and username for previous activity
        Intent  intent = getIntent();
        username = intent.getStringExtra("Username");

        editTextUser=(EditText) findViewById(R.id.editTextUser);
        send =(Button) findViewById(R.id.buttonSendUser);
        tv =(TextView)findViewById(R.id.textViewUser);
        nameLabel = (TextView)findViewById(R.id.textViewMessageUser);

        nameLabel.setText(psychologist_name);// Set the username in nameLabel

        StringBuilder str = new StringBuilder();//Initialized StingBuilder str
        str.append("Chat-"+username+".txt"); // Append the filename created to stringbuilder str .EXAMPLE OF Filename :Chat-JAMES



        filename = str.toString(); //Convert the StringBuilder str to string


        File file = getFileStreamPath(filename); // Initialize a file using the filename

        try {
            if (file.exists()) {  //IF file exist,create file using MODE_APPEND , to append message
                fos = openFileOutput(filename, MODE_APPEND);

            }
            else {
                fos = openFileOutput(filename, MODE_PRIVATE); // If file not exist , create new file using MODE_PRIVATE ,to insert message
            }


            send.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) { //Click on the button " send"

                    try {


                        StringBuilder str1 = new StringBuilder(); // Initialize a String Builder
                        strFileContents = (editTextUser.getText()).toString(); // Get the text from EditText edit after user write message on it
                        str1.append("\n"+ username + " " + ":" + " " + strFileContents); // Append the message to stringbuilder str
                        str1.append("\n");
                        text = str1.toString();//Convert the stringBuilder to string
                        tv.append(text);//Append the text to the TextView tv.
                        tv.append("\n");



                        fos.write(text.getBytes());//Write the String text to the file
                        editTextUser.getText().clear();//Clear the EditText edit


                    } catch (IOException e) {
                        e.printStackTrace(); //If any error occur , it will display error message
                    }
                }
            });





        }catch(Exception e){
            e.printStackTrace();//If any error occur , it will display error message
        }



        /////////////////////////////////////////////////////////////////////
        // This Part is to get the conservation between psychologist and user from specific file created before

        FileInputStream fis ;
        StringBuffer buffer = new StringBuffer();
        BufferedReader br ;

        String strLine = null ;
        try {
            fis = openFileInput(filename); //Open the file
            br = new BufferedReader(new InputStreamReader(fis));
            while((strLine=br.readLine())!= null){

                buffer.append(strLine + "\n");//If the file not empty , it will append line by line from file to StringBuffer buffer



            }
        }catch(Exception e ){
            e.printStackTrace();//If any error occur , it will display error message
        }

        tv.setText(new String(buffer)) ;// Set the data in StringBuffer to TextView tv
        tv.setMovementMethod(new ScrollingMovementMethod());//Set scrolling at the TetxtView tv
    }
}