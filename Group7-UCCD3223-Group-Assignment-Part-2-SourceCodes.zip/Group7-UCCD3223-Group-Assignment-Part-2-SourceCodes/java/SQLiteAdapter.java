package com.example.mad_assignment;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class SQLiteAdapter {
    public static final String DATABASE_NAME = "DATABASE";
    public static final int VERSION = 1;

    public static final String DATABASE_TABLE = "INFO_TABLE";
    public static final String ID = "ID";
    public static final String F_NAME = "FIRST";
    public static final String L_NAME = "LAST";
    public static final String USERNAME = "USERNAME";
    public static final String PASSWORD = "PASSWORD";
    public static final String DOB = "DOB";

    private static final String SCRIPT_CREATE_TABLE = "create table "
            + DATABASE_TABLE + " (" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + F_NAME + " text, "
            + L_NAME + " text, "
            + USERNAME + " text not null,"
            + PASSWORD + " text not null, "
            + DOB + " text not null);";


    public static final String DATABASE_TABLE_TASK = "TASK_TABLE";
    public static final String IDTT = "ID";
    public static final String TASK = "TASK";
    public static final String TIME = "TIME";
    public static final String MARK = "MARK";

    private static final String SCRIPT_CREATE_TABLE_TASK = "create table "
            + DATABASE_TABLE_TASK + " (" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + USERNAME + " text not null,"
            + MARK + " int,"
            + TASK + " text not null, "
            + TIME + " text not null);";

    private SQLiteHelper sqLiteHelper;
    private SQLiteDatabase  sqLiteDatabase;

    private Context context;

    public SQLiteAdapter(Context c){
        context = c;
    }

    public SQLiteAdapter openToRead() throws android.database.SQLException{
        sqLiteHelper = new SQLiteHelper(context, DATABASE_NAME, null, VERSION);
        sqLiteDatabase = sqLiteHelper.getReadableDatabase();

        return this;
    }

    public SQLiteAdapter openToWrite() throws android.database.SQLException{
        sqLiteHelper = new SQLiteHelper(context, DATABASE_NAME, null, VERSION);
        sqLiteDatabase = sqLiteHelper.getWritableDatabase();

        return this;
    }

    public void close(){
        sqLiteHelper.close();
    }

    public long insert(String f_NAME, String l_NAME, String Username, String Password, String Dob){
        ContentValues contentValues = new ContentValues();
        contentValues.put(F_NAME, f_NAME);
        contentValues.put(L_NAME, l_NAME);
        contentValues.put(USERNAME, Username);
        contentValues.put(PASSWORD, Password);
        contentValues.put(DOB, Dob);

        return sqLiteDatabase.insert(DATABASE_TABLE, null, contentValues);
    }

    public int deleteAll(){
        return sqLiteDatabase.delete(DATABASE_TABLE, null, null);
    }

    public String queueAll(){
        String[] columns = new String[] {ID, F_NAME, L_NAME, USERNAME, PASSWORD, DOB};

        Cursor cursor = sqLiteDatabase.query(DATABASE_TABLE, columns, null, null, null, null, null);
        String result = "";

        int index1 = cursor.getColumnIndex(ID);
        int index2 = cursor.getColumnIndex(F_NAME);
        int index3 = cursor.getColumnIndex(L_NAME);
        int index4 = cursor.getColumnIndex(USERNAME);
        int index5 = cursor.getColumnIndex(PASSWORD);
        int index6 = cursor.getColumnIndex(DOB);

        for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){
            result = result + cursor.getString(index1) + ". " + cursor.getString(index2) + " " + cursor.getString(index3) + ", " + cursor.getString(index4)
                    + ", " + cursor.getString(index5) + ", " + cursor.getString(index6) + "\n";
        }

        return result;
    }

    public ArrayList<String> queryUsername(){
        String [] columns = new String[] {USERNAME};

        Cursor cursor = sqLiteDatabase.query(DATABASE_TABLE, columns, null,null,null,null,null);

        ArrayList<String> result = new ArrayList<String>();
        int index = cursor.getColumnIndex(USERNAME);

        for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){
            result.add(cursor.getString(index));
        }

        return result;
    }

    public ArrayList<String> queryPassword(){
        String[] columns = new String[] {PASSWORD};

        Cursor cursor = sqLiteDatabase.query(DATABASE_TABLE, columns, null,null,null,null,null);

        ArrayList<String> result = new ArrayList<String>();
        int index = cursor.getColumnIndex(PASSWORD);

        for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){
            result.add(cursor.getString(index));
        }

        return result;
    }
    public ArrayList<String> queryfirstname(){
        String [] columns = new String[] {F_NAME};

        Cursor cursor = sqLiteDatabase.query(DATABASE_TABLE, columns, null,null,null,null,null);

        ArrayList<String> result = new ArrayList<String>();
        int index = cursor.getColumnIndex(F_NAME);

        for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){
            result.add(cursor.getString(index));
        }

        return result;
    }

    public ArrayList<String> querylastname(){
        String [] columns = new String[] {L_NAME};

        Cursor cursor = sqLiteDatabase.query(DATABASE_TABLE, columns, null,null,null,null,null);

        ArrayList<String> result = new ArrayList<String>();
        int index = cursor.getColumnIndex(L_NAME);

        for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){
            result.add(cursor.getString(index));
        }

        return result;
    }

    public ArrayList<String> querydateofbirth(){
        String[] columns = new String[] {DOB};

        Cursor cursor = sqLiteDatabase.query(DATABASE_TABLE, columns, null,null,null,null,null);

        ArrayList<String> result = new ArrayList<String>();
        int index = cursor.getColumnIndex(DOB);

        for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){
            result.add(cursor.getString(index));
        }

        return result;
    }

    public class SQLiteHelper extends SQLiteOpenHelper {
        public SQLiteHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(SCRIPT_CREATE_TABLE);
            db.execSQL(SCRIPT_CREATE_TABLE_TASK);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        }
    }

    ///////////////////////////////////////////TaskList's DATABASE/////////////////////////////////////

    public long insert_task ( String Username, int Mark, String Task, String Time){
        ContentValues contentValues = new ContentValues();
        contentValues.put(USERNAME, Username);
        contentValues.put(MARK, Mark);
        contentValues.put(TASK, Task);
        contentValues.put(TIME, Time);

        return sqLiteDatabase.insert(DATABASE_TABLE_TASK, null, contentValues);
    }

    public int deleteAll_task()
    {
        return sqLiteDatabase.delete(DATABASE_TABLE_TASK, null, null);
    }

    public String queueAll_task(){
        String[] columns = new String[] {ID, MARK, TASK, TIME};

        Cursor cursor = sqLiteDatabase.query(DATABASE_TABLE_TASK, columns, null, null, null, null, null);
        String result = "";

        int index1 = cursor.getColumnIndex(ID);
        int index2 = cursor.getColumnIndex(USERNAME);
        int index3 = cursor.getColumnIndex(MARK);
        int index4 = cursor.getColumnIndex(TASK);
        int index5 = cursor.getColumnIndex(TIME);

        for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){
            result = result + cursor.getString(index1) + ". " + cursor.getString(index2) + ", " + cursor.getString(index3) + ", " + cursor.getString(index4)
                    + ", " + cursor.getString(index5) + "\n";
        }

        return result;
    }

    public boolean isEmpty(){

        Cursor mCursor = sqLiteDatabase.rawQuery("SELECT * FROM " + DATABASE_TABLE_TASK, null);
        Boolean rowExists;

        if (mCursor.moveToFirst())
            rowExists = false;
        else
            rowExists = true;

        return rowExists;
    }

    public ArrayList<Integer> queryMark(String user){
        String [] columns = new String[] {MARK};

        Cursor cursor = sqLiteDatabase.query(DATABASE_TABLE_TASK, columns, USERNAME + "=?", new String [] {user}, null,null,null);

        ArrayList<Integer> result = new ArrayList<Integer>();
        int index = cursor.getColumnIndex(MARK);

        for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){
            result.add(cursor.getInt(index));
        }

        return result;
    }

    public ArrayList<String> queryTask(String user){
        String[] columns = new String[] {TASK};

        Cursor cursor = sqLiteDatabase.query(DATABASE_TABLE_TASK, columns, USERNAME + "=?",new String [] {user}, null,null,null);

        ArrayList<String> result = new ArrayList<String>();
        int index = cursor.getColumnIndex(TASK);

        for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){
            result.add(cursor.getString(index));
        }

        return result;
    }

    public ArrayList<String> queryTime(String user){
        String[] columns = new String[] {TIME};

        Cursor cursor = sqLiteDatabase.query(DATABASE_TABLE_TASK, columns, USERNAME + "=?", new String [] {user}, null,null,null);

        ArrayList<String> result = new ArrayList<String>();
        int index = cursor.getColumnIndex(TIME);

        for(cursor.moveToFirst(); !(cursor.isAfterLast()); cursor.moveToNext()){
            result.add(cursor.getString(index));
        }

        return result;
    }


}
