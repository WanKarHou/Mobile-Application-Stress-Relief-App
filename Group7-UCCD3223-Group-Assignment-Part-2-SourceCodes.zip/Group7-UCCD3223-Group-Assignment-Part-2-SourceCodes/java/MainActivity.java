package com.example.mad_assignment;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView i = (ImageView) findViewById(R.id.logo);
        i.setImageResource(R.drawable.login_register_background_2);

        AlphaAnimation alpha = new AlphaAnimation(0.0f, 1.0f);
        alpha.setDuration(5000);

        i.startAnimation(alpha);

        AlphaAnimation alpha2 = new AlphaAnimation(0.0f, 1.0f);
        alpha2.setDuration(5000);
        alpha2.setStartOffset(2500);

        TextView t1 = (TextView)findViewById(R.id.textView);
        t1.startAnimation(alpha2);

        t1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, LOGIN_REGISTER_2.class);
                startActivity(i);
            }
        });
    }
}