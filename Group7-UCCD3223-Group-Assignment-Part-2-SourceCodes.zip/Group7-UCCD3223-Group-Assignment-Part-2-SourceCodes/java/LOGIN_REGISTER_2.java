package com.example.mad_assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class LOGIN_REGISTER_2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_register_2);

        final SQLiteAdapter adapter = new SQLiteAdapter(this);

        //set both edittext field to a variable
        final EditText EUsername = (EditText)findViewById(R.id.username);
        final EditText EPassword = (EditText)findViewById(R.id.password);

        //set button to a variable
        Button BRegister = (Button) findViewById(R.id.ButtonRegister);
        Button BLogin = (Button)findViewById(R.id.ButtonLogin);
        Button BGuest = (Button)findViewById(R.id.ButtonGuest);

        //register button
        BRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //go to register activity
                Intent i = new Intent(LOGIN_REGISTER_2.this, LOGIN_REGISTER_3.class);
                startActivity(i);
            }
        });

        //login button
        BLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                //get the user input field convert to a string
                String username = EUsername.getText().toString();
                String password = EPassword.getText().toString();

                //open our SQLite database and query all the username , password ,lastname,firstname and date of birth
                adapter.openToRead();
                ArrayList<String> queryUsername = adapter.queryUsername();
                ArrayList<String> queryPassword = adapter.queryPassword();

                ArrayList<String> queryFirstName = adapter.queryfirstname();
                 ArrayList<String> queryLastName = adapter.querylastname();
                 ArrayList<String> queryDateOfBirth = adapter.querydateofbirth();
                adapter.close();



                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////

                //This part is to check the SQLite Database and create specific account for psychologist if it is not created previously
                int status =0;

                for(int i = 0; i < queryUsername.size(); i++){
                    if((queryUsername.get(i).equals("Psychologist") && queryPassword.get(i).equals("iampsychologist"))||(queryUsername==null)){
                        status=1;

                        break;
                    }
                }

                if(status==0)
                {
                    adapter.openToWrite();
                    adapter.insert("James", "Wan", "Psychologist", "iampsychologist","28/07/2020");
                    queryUsername.add("Psychologist");
                    queryPassword.add("iampsychologist");
                    adapter.close();

                }
                ///////////////////////////////////////////////////////////////////////////////////////////////////////
                int success = 0;

                //check if a field is empty
                if(username.isEmpty() || password.isEmpty()){
                    Toast.makeText(getApplicationContext(), "Username and Password cannot be empty... ", Toast.LENGTH_SHORT).show();
                }
                //check if both username and password in database are empty
                else if(queryUsername.size() == 0 || queryPassword.size() == 0){
                    Toast.makeText(getApplicationContext(), "Incorrect Username or Password.... Please try again....", Toast.LENGTH_SHORT).show();
                }
                else{
                    //psychologist login
                    for(int i = 0; i < queryUsername.size(); i++){
                        if(username.equals("Psychologist") && password.equals("iampsychologist"))
                        {
                            Toast.makeText(getApplicationContext(), "Successfully login as psychologist...", Toast.LENGTH_SHORT).show();
                            success=1;
                            Intent psy = new Intent(LOGIN_REGISTER_2.this, Select_User_To_Chat.class);
                            startActivity(psy);

                            break;
                        }
                        //user login
                        else if(queryUsername.get(i).equals(username) && queryPassword.get(i).equals(password)){
                            //proceed to "select options" activity
                            //Intent intent = new Intent(MainActivity2.this, (Options Activity));
                            //startActivity(intent);

                            Toast.makeText(getApplicationContext(), "Successfully login..."+"Welcome..."+username, Toast.LENGTH_SHORT).show();
                            Intent option = new Intent(LOGIN_REGISTER_2.this, Select_Options.class);
                            option.putExtra("Username",username);//The username selected  was pass to next activity
                            option.putExtra("FirstName",queryFirstName.get(i)); //The firstname of selected user pass to next activity
                            option.putExtra("LastName",queryLastName.get(i));
                            option.putExtra("Password",queryPassword.get(i));
                            option.putExtra("DateOfBirth",queryDateOfBirth.get(i));
                            startActivity(option);
                            success = 1;
                            break;
                        }
                    }

                    //if username or password doesn't match
                    if(success == 0){
                        Toast.makeText(getApplicationContext(), "Incorrect Username or Password.... Please try again....", Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });

        //guest button
        BGuest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Proceed to guest options
                Intent GuestOption = new Intent(LOGIN_REGISTER_2.this, Gust_Options.class);
                startActivity(GuestOption);
            }
        });

    }
}
