package com.example.mad_assignment;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Profile extends AppCompatActivity {

    TextView usernametv ,firstnametv,lastnametv,passwordtv,dateofbirthtv;

    String Username;
    String Password;
    String LastName;
    String FirstName;
    String DateOfBirth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        Intent intent = getIntent();

        Username = intent.getStringExtra("Username");
        FirstName = intent.getStringExtra("FirstName");
        LastName = intent.getStringExtra("LastName");
        Password = intent.getStringExtra("Password");
        DateOfBirth=intent.getStringExtra("DateOfBirth");

        usernametv = (TextView) findViewById(R.id.fullName);
        passwordtv = (TextView) findViewById(R.id.Password);
       firstnametv = (TextView) findViewById(R.id.FirstName);
       lastnametv=(TextView) findViewById(R.id.LastName);
       dateofbirthtv=(TextView)findViewById(R.id.DateOfBirth);

       usernametv.setText(Username);
       passwordtv.setText("Password:"+Password);
       firstnametv.setText("FirstName:"+FirstName);
        lastnametv.setText("LastName:"+LastName);
        dateofbirthtv.setText("DateOfBirth:"+DateOfBirth);


    }
}