package com.example.mad_assignment;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.mikhaellopez.circularprogressbar.CircularProgressBar;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivityTL extends AppCompatActivity {

    String User;//current user logged in
    double totalcom;
    ArrayList<Integer> Mark;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_t_l);

        double pro;
        totalcom = 0;
        TextView comment = findViewById(R.id.comment);
        TextView percent = findViewById(R.id.percentage);
        Button TaskList = findViewById(R.id.button);
        Intent in =  getIntent();
        User = in.getStringExtra("Username");// basically this is to get the user's username to know who is logged in

        TaskList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent (MainActivityTL.this, TaskCustomer.class);
                i.putExtra("Username",User);
                startActivity(i);
            }
        });

        //create a progress bar of the users task progress
        CircularProgressBar CPB = findViewById(R.id.CPB);

        //get data of the tasklist
        SQLiteAdapter SQLData = new SQLiteAdapter(this);

        SQLData.openToWrite();
        if(SQLData.isEmpty() == true)
        {
            SQLData.insert_task(User, 0, "Hi Please add some Task", " ");
        }
        SQLData.close();

        SQLData.openToRead();
        Mark = SQLData.queryMark(User);
        SQLData.close();

        //calculate the total complete task
        for(int i = 0; i < Mark.size(); i++)
        {
            totalcom= totalcom + Mark.get(i);
        }
        double total = Mark.size();
        pro = (totalcom/total) * 100;

        CPB.setProgressMax(100); // Set Progress Max
        CPB.setProgressWithAnimation((int)pro, 1000L); //Set Progress with Animation
        //Set Width
        CPB.setProgressBarWidth(10f);
        CPB.setBackgroundProgressBarWidth(20f);
        CPB.setBackgroundProgressBarColor(Color.LTGRAY); //Set progressBar Color
        CPB.setProgressBarColor(Color.RED);//Set Background ProgressBar Color

        //motivation texts
        percent.setText(Integer.toString((int)pro)+"%");

        if(pro == 0)
        {
            comment.setText("Feel Stressful? "+"\nTry to add some task or complete those task you added to release your stress.");
        }
        else if(pro == 100)
        {
            comment.setText("Congratulations!!!!\n"+"You're finally distressed.");
        }
        else if(pro >= 1 && pro <= 50)
        {
            comment.setText("There are still task You haven't done.\n"+"Keep it up!");
        }
        else if(pro >=51 && pro <= 99)
        {
            comment.setText("You're almost there...\n"+"The last few remaining task may also help you release the remaining stress.");
        }

    }
}