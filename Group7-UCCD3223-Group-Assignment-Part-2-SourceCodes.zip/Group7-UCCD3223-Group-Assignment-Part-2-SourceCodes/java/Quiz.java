package com.example.mad_assignment;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;

public class Quiz extends AppCompatActivity {

    Button Quizbutton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        addListenerOnButton();

    }

    public void addListenerOnButton() {

        //Select a specific button to bundle it with the action you want
        Quizbutton = (Button) findViewById(R.id.buttonAttempt);

        Quizbutton.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent openBrowser =  new Intent(Intent.ACTION_VIEW, Uri.parse("https://greatergood.berkeley.edu/quizzes/take_quiz/stress_and_anxiety"));
                startActivity(openBrowser);
            }

        });

    }

}
