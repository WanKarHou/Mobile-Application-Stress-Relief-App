package com.example.mad_assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Select_Options extends AppCompatActivity {

    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;

    String Username;
    String Password;
    String LastName;
    String FirstName;
    String DateOfBirth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select__options);

        Intent intent = getIntent();

        Username = intent.getStringExtra("Username");
        FirstName = intent.getStringExtra("FirstName");
        LastName = intent.getStringExtra("LastName");
        Password = intent.getStringExtra("Password");
        DateOfBirth = intent.getStringExtra("DateOfBirth");
        addListenerOnButton();
    }
    public void addListenerOnButton() {
        //Select a specific button to bundle it with the action you want
        button1 = (Button) findViewById(R.id.buttonTutorial);
        button2 = (Button) findViewById(R.id.buttonQuizTest);
        button3 = (Button) findViewById(R.id.buttonDailyTask);
        button4 = (Button) findViewById(R.id.buttonChatWithPsychologist);
        button5 = (Button) findViewById(R.id.buttonProfile);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tutorial = new Intent(Select_Options.this, Tutorial.class);

                startActivity(tutorial);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent quiz = new Intent(Select_Options.this, Quiz.class);

                startActivity(quiz);
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent dailyTask = new Intent(Select_Options.this, MainActivityTL.class);
                dailyTask.putExtra("Username", Username);


                startActivity(dailyTask);
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent userChat = new Intent(Select_Options.this, User_Chat.class);
                userChat.putExtra("Username",Username);//The username selected from the radio button was pass to next activity
                startActivity(userChat);
            }
        });

        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent profile = new Intent(Select_Options.this, Profile.class);
                profile.putExtra("Username",Username);
                profile.putExtra("Password",Password);
                profile.putExtra("LastName",LastName);
                profile.putExtra("FirstName",FirstName);
                profile.putExtra("DateOfBirth",DateOfBirth);


                startActivity(profile);
            }
        });

    }
}