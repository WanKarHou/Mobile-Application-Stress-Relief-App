package com.example.mad_assignment;



import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class TaskCustomer extends AppCompatActivity {

    String User;
    ArrayList<String> selectedItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_customer);

        SwipeMenuListView TaskList = findViewById(R.id.Task);
        TaskList.setChoiceMode(SwipeMenuListView.CHOICE_MODE_MULTIPLE);
        Intent PreAct = getIntent();
        User = PreAct.getStringExtra("Username");// basically this is to get the user's username to know who is logged in

        //create the TextView to show the task
        final SQLiteAdapter SQLData = new SQLiteAdapter(this);

        SQLData.openToRead();
        final ArrayList<String> Task = SQLData.queryTask(User);
        final ArrayList<String> Time = SQLData.queryTime(User);
        final ArrayList<Integer> Mark = SQLData.queryMark(User);
        SQLData.close();

        final List<UserModel> TaskLists = new ArrayList<>();

        for(int j = 0; j < Task.size(); j++)
        {
            String a = "  " + Task.get(j) +" ( "+ Time.get(j) + ")";
            if(Mark.get(j) == 0)
            {
                TaskLists.add(new UserModel(false, a));
            }
            else if (Mark.get(j) == 1)
            {
                TaskLists.add(new UserModel(true, a));
            }
        }
        //create checkbox
        final CustomAdapter adapter = new CustomAdapter(this, TaskLists);
        TaskList.setAdapter(adapter);

        TaskList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView,View view, int i, long l )
            {
                UserModel model = TaskLists.get(i);
                int num =0;
                if(model.isSelected())
                {
                    model.setSelected(false);
                }
                else
                {
                    model.setSelected(true);
                    num = 1;
                }


                TaskLists.set(i, model);
                Mark.set(i, num);

                //noew update adapter
                adapter.updateRecord(TaskLists);

            }

        });

        //create a SwipeMenu for each tasks for edit and delete
        /*SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {
                // create "delete" item
                SwipeMenuItem deleteItem = new SwipeMenuItem(
                        getApplicationContext());
                // set item background
                deleteItem.setBackground(new ColorDrawable(Color.rgb(0xF9,
                        0x3F, 0x25)));
                // set item width
                deleteItem.setWidth(170);
                // set a icon
                deleteItem.setTitle("Delete");
                // add to menu
                menu.addMenuItem(deleteItem);
            }
        };

        // set creator
        TaskList.setMenuCreator(creator);

        //action of the buttons from the swipe menu
        TaskList.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                switch (index) {
                    case 0:
                        // delete

                        break;
                }
                // false : close the menu; true : not close the menu
                return false;
            }
        });*/
        FloatingActionButton back = findViewById(R.id.backPrevious);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(TaskCustomer.this, MainActivityTL.class);
                i.putExtra("Username",User);
                //store back all the task
                SQLData.openToWrite();
                SQLData.deleteAll_task();
                for(int k = 0; k < Task.size(); k++)
                {
                    SQLData.insert_task(User, Mark.get(k), Task.get(k), Time.get(k));
                }
                SQLData.close();
                startActivity(i);
            }
        });

        //add task button function
        FloatingActionButton add = findViewById(R.id.AddFAB);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(TaskCustomer.this, AddTask.class);
                i.putExtra("Username",User);
                startActivity(i);
            }
        });

    }

}