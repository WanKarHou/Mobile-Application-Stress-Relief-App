package com.example.mad_assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Gust_Options extends AppCompatActivity {
    Button Guestbutton1;
    Button Guestbutton2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gust__options);

        Guestbutton1 = (Button) findViewById(R.id.Guestbutton1);
        Guestbutton2 = (Button) findViewById(R.id.Guestbutton2);


        Guestbutton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent tutorial = new Intent(Gust_Options.this, Tutorial.class);

                startActivity(tutorial);
            }
        });

        Guestbutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent quiz = new Intent(Gust_Options.this, Quiz.class);

                startActivity(quiz);
            }
        });



    }
}