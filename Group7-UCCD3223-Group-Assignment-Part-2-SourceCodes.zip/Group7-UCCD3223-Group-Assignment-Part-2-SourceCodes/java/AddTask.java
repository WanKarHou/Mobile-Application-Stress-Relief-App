package com.example.mad_assignment;


import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.icu.util.Calendar;
import android.os.Build;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.ArrayList;

public class AddTask extends AppCompatActivity {
    int hr;
    int min;
    EditText TaskN;
    EditText Duration;
    String User;
    String Time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        Button addTask = new Button(this);
        TextView TaskNT = new TextView(this);
        TextView DurationT = new TextView(this);
        TaskN = new EditText(this);
        Duration = new EditText(this);
        final SQLiteAdapter SQLAdapter = new SQLiteAdapter(this);
        Intent in =  getIntent();
        User = in.getStringExtra("Username");// basically this is to get the user's username to know who is logged in

        TaskNT.setText("Task: ");
        DurationT.setText("Duration: ");
        addTask.setText("Create");

        //Show the num of Hours and Minutes of the task
        Duration.setOnClickListener(new View.OnClickListener()
        {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View view)
            {
                final Calendar c = Calendar.getInstance();
                min = c.get(Calendar.MINUTE);
                hr = c.get(Calendar.HOUR_OF_DAY);

                // time picker dialog
                TimePickerDialog picker = new TimePickerDialog(AddTask.this,
                        new TimePickerDialog.OnTimeSetListener()
                        {
                            @Override
                            public void onTimeSet(TimePicker timePicker, int hour, int minute)
                            {
                                if(hour == 0)
                                {
                                    Duration.setText(minute +" Min");// show only the text of the minute select when hour is 0
                                    Time = minute +" Min";
                                }

                                else if (minute == 0)
                                {
                                    Duration.setText(hour + " Hr ");// show only the text of the hours select when minute is 0
                                    Time = hour + " Hr ";
                                }

                                else
                                {
                                    Duration.setText(hour + " Hr " + minute +" Min");//show the text of the hours and minute
                                    Time = hour + " Hr " + minute +" Min";
                                }

                            }

                        }, hr, min, DateFormat.is24HourFormat(AddTask.this));


                picker.show();
            }

        });


        addTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tempTaskN = TaskN.getText().toString();
                int NewMark = 0;

                SQLAdapter.openToRead();
                ArrayList<String> Task = SQLAdapter.queryTask(User);
                SQLAdapter.close();
                if(Task.get(0).equals("Hi Please add some Task") )
                {
                    SQLAdapter.openToWrite();
                    SQLAdapter.deleteAll_task();
                    SQLAdapter.insert_task(User, NewMark, tempTaskN, Time);
                    SQLAdapter.close();
                }
                else
                {
                    SQLAdapter.openToWrite();
                    SQLAdapter.insert_task(User, NewMark, tempTaskN, Time);
                    SQLAdapter.close();
                }

                Intent i = new Intent(AddTask.this, TaskCustomer.class);
                i.putExtra("Username",User);
                startActivity(i);
            }
        });

        LinearLayout L = new LinearLayout(this);
        L.setOrientation(LinearLayout.VERTICAL);
        L.addView(TaskNT);
        L.addView(TaskN);
        L.addView(DurationT);
        L.addView(Duration);
        L.addView(addTask);

        setContentView(L);

    }
}