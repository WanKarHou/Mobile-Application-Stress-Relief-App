package com.example.mad_assignment;




//IMPORT OF USEFUL RESOURCES
import android.app.Activity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import java.util.ArrayList;

public class Select_User_To_Chat extends Activity {

    int radio_buttons = 0; // Initialize the radio button number to 0
    String file_name="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select__user__to__chat);

        ////////////////////////////////////////////////////////////////////////////////////
        //This part is to initialize SQLite Database , get the list of username from SQLite

        final SQLiteAdapter adapter = new SQLiteAdapter(this);  //  initialize SQLiteAdapter
        SQLiteAdapter mySQLiteAdapter = new SQLiteAdapter(this);
        //mySQLiteAdapter.openToWrite();  //  Open SQLiteAdapter mySQLiteAdapter to write
        // mySQLiteAdapter.deleteAll();
        // mySQLiteAdapter.insert("Terry", "Teh", "TerryTeh", "18/01/2020","18/01/2020");
        //  mySQLiteAdapter.insert("Mike", "Tan", "Mike", "28/07/2020","28/07/2020");

        mySQLiteAdapter.openToRead();   // Open my SQLiteAdapter to read
        ArrayList<String> contentRead = mySQLiteAdapter.queryUsername();    //  Get all the Username in mySQLiteAdapter to an ArrayList<String> contentRead
        for(int i=0;i<contentRead.size();i++)
        {
            if(contentRead.get(i).equals("Psychologist")) // REMOVE THE username "Psychologist " in the list of username
            {
                contentRead.remove(i);
            }
        }
        radio_buttons = contentRead.size();   // Set the number of buttons with the size of ArrayList<String> contentRead
        mySQLiteAdapter.close();

        ////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////
        //This part is to create radio buttons in radiogroup based on the username in ArrayList<String> contentRead

        LinearLayout ll3 = new LinearLayout(this);
        ll3.setOrientation(LinearLayout.VERTICAL);

        RadioGroup rgp = (RadioGroup) findViewById(R.id.radioGroup1); // Get the Radio Group
        for (int i = 0; i < radio_buttons ; i++) {          // Create radio buttons  and added in into radio group
            RadioButton rbn = new RadioButton(this); // Initialized a radio button
            int count = i+1;
            rbn.setId(count); //Set the id of radio button
            rbn.setText(contentRead.get(i));//Set the text of radio button with the username get from the ArrayList<String> contentRead
            rbn.setTextColor(Color.parseColor("#FF0000"));//Set the color of text in radio button to red color
            rbn.setTextSize(25);// Set the text Size to 25

            rgp.addView(rbn); // Add the radio button to Radio Group

        }
        ////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////
        //This part is to create the name of file based on the text of radio button selected , then pass it to next activity
        // The name of file create was use to create file with the name of it in next activity to store the conversation message between psychologist and specific user

        rgp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) { // When a radio button selected
                RadioButton rb = (RadioButton) group.findViewById(checkedId);
                if (null != rb & checkedId>-1) {
                    StringBuilder str = new StringBuilder();//Initialized StingBuilder str
                    String name = rb.getText().toString(); //Convert the text in radio button selected to String
                    str.append("Chat-"+name+".txt"); // Append the filename created to stringbuilder str .EXAMPLE OF Filename :Chat-JAMES


                    Toast.makeText(Select_User_To_Chat.this, rb.getText(), Toast.LENGTH_SHORT).show();//Show the username selected to chat
                    file_name = str.toString(); //Convert the StringBuilder str to string

                }


                // Access to next activity
                Intent i = new Intent(Select_User_To_Chat.this , Psychologist_Chat.class);
                i.putExtra("SelectedChat", file_name);// The file name was pass to next activity
                i.putExtra("Username",rb.getText().toString());//The username selected from the radio button was pass to next activity

                startActivity(i);



            }
        });
    }
}