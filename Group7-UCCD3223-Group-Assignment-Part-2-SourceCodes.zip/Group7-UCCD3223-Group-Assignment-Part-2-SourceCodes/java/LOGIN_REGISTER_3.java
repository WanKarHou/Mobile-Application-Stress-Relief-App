package com.example.mad_assignment;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class LOGIN_REGISTER_3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_register_3);

        final SQLiteAdapter adapter = new SQLiteAdapter(this);

        ////////////////////////////////////////////////////////////////////////////////////////////
        //Typeface section
        Typeface type = Typeface.create(Typeface.SERIF, Typeface.BOLD);
        Typeface typeView = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);

        ////////////////////////////////////////////////////////////////////////////////////////////
        //TextView section
        TextView VRegister = (TextView)findViewById(R.id.ViewRegister);

        VRegister.setTypeface(type);

        TextView VF_Name = (TextView)findViewById(R.id.VF_NAME);
        TextView VL_Name = (TextView)findViewById(R.id.VL_NAME);
        TextView VUsername = (TextView)findViewById(R.id.VUsername);
        TextView VPassword = (TextView)findViewById(R.id.VPassword);
        TextView VCPassword = (TextView)findViewById(R.id.VCPassword);
        TextView VDOB = (TextView)findViewById(R.id.VDOB);

        VF_Name.setTypeface(typeView);
        VL_Name.setTypeface(typeView);
        VUsername.setTypeface(typeView);
        VPassword.setTypeface(typeView);
        VCPassword.setTypeface(typeView);
        VDOB.setTypeface(typeView);

        //set all the edittext field to a variable
        final EditText EF_NAME = (EditText)findViewById(R.id.EF_NAME);
        final EditText EL_NAME = (EditText)findViewById(R.id.EL_NAME);
        final EditText EUsername = (EditText)findViewById(R.id.EUsername);
        final EditText EPassword = (EditText)findViewById(R.id.EPassword);
        final EditText ECPassword = (EditText)findViewById(R.id.ECPassword);
        final EditText EDOB = (EditText)findViewById(R.id.EDOB);

        Button BCRegister = (Button)findViewById(R.id.BCRegister);

        BCRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get all the editext field can convert to string
                String fName = EF_NAME.getText().toString();
                String lName = EL_NAME.getText().toString();
                String username = EUsername.getText().toString();
                String password = EPassword.getText().toString();
                String cpassword = ECPassword.getText().toString();
                String dob = EDOB.getText().toString();

                adapter.openToRead();
                ArrayList<String> queryUsername = adapter.queryUsername();
                adapter.close();

                int success = 1;

                //check if one of the field is empty
                if(fName.isEmpty() || lName.isEmpty() || username.isEmpty() || password.isEmpty() || dob.isEmpty()){
                    Toast.makeText(getApplicationContext(), "None of these fields can be empty.. ", Toast.LENGTH_SHORT).show();
                }
                //check valid date format
                else if(!checkValidDate(dob)){
                    Toast.makeText(getApplicationContext(), "Invalid date format...", Toast.LENGTH_SHORT).show();
                }
                //check password match
                else if (!password.equals(cpassword)){
                    Toast.makeText(getApplicationContext(), "Both password doesn't match... Please try again... ", Toast.LENGTH_SHORT).show();
                }
                else{
                    //check for if got a duplicate username
                    for(int i = 0; i < queryUsername.size(); i++){
                        if(queryUsername.get(i).equals(username)){
                            Toast.makeText(getApplicationContext(), "Username chosen used by others... Please try again....", Toast.LENGTH_SHORT).show();
                            success = 0;
                        }
                    }

                    //success register
                    if(success == 1){
                        adapter.openToWrite();
                        adapter.insert(fName, lName, username, password, dob);
                        adapter.close();

                        Toast.makeText(getApplicationContext(), "Successfully Registered!", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(LOGIN_REGISTER_3.this, LOGIN_REGISTER_2.class);
                        startActivity(intent);
                    }
                }
            }
        });
    }

    private boolean checkValidDate(String date){
        if(date.charAt(2) != '/' || date.charAt(5) != '/'){
            return false;
        }
        else if(date.charAt(0) == '0' && date.charAt(1) == '0'){
            return false;
        }
        else if(date.charAt(0) != '0' && date.charAt(0) != '1' && date.charAt(0) != '2' && date.charAt(0) != '3'){
            return false;
        }
        else if((date.charAt(0) == '3' && date.charAt(1) != '0') && (date.charAt(0) == '3' && date.charAt(1) != '1')){
            return false;
        }
        else if((date.charAt(1)-48) < 0 || (date.charAt(1)-48) > 9){
            return false;
        }
        else if(date.charAt(3) == '0' && date.charAt(4) == '0'){
            return false;
        }
        else if (date.charAt(3) != '0' && date.charAt(3) != '1'){
            return false;
        }
        else if((date.charAt(3) == '1' && date.charAt(4) != '0') && (date.charAt(3) == '1' && date.charAt(4) != '1') && (date.charAt(3) == '1' && date.charAt(4) != '2')){
            return false;
        }
        else if((date.charAt(4)-48) < 0 || (date.charAt(4)-48) > 9){
            return false;
        }
        else
            return true;
    }
}