package com.example.mad_assignment;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class Tutorial extends AppCompatActivity {
    ImageButton  Imagebutton1;
    ImageButton Imagebutton2;
    ImageButton Imagebutton3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);
        addListenerOnButton();
    }
    public void addListenerOnButton() {

        //Select a specific button to bundle it with the action you want
        Imagebutton1 = (ImageButton) findViewById(R.id.Imagebutton1);
        Imagebutton2 = (ImageButton) findViewById(R.id.Imagebutton2);
        Imagebutton3 = (ImageButton) findViewById(R.id.Imagebutton3);

        Typeface typeView = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD);
        TextView t1 = (TextView)findViewById(R.id.textView6);
        TextView t2 = (TextView)findViewById(R.id.textView4);
        TextView t3 = (TextView)findViewById(R.id.textView7);

        t1.setTypeface(typeView);
        t2.setTypeface(typeView);
        t3.setTypeface(typeView);

        Imagebutton1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent openBrowser =  new Intent(Intent.ACTION_VIEW, Uri.parse("https"
                        + "://www.youtube.com/watch?v=1ZYbU82GVz4"));
                startActivity(openBrowser);
            }


        });

        Imagebutton2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent openBrowser =  new Intent(Intent.ACTION_VIEW, Uri.parse("https"
                        + "://www.youtube.com/watch?v=inpok4MKVLM"));
                startActivity(openBrowser);
            }


        });


        Imagebutton3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent openBrowser =  new Intent(Intent.ACTION_VIEW, Uri.parse("https"
                        + "://www.youtube.com/watch?v=v7AYKMP6rOE&t=4s"));
                startActivity(openBrowser);
            }
        });


    }
}